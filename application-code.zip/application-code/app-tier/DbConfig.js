module.exports = Object.freeze({
    DB_HOST : 'projectdb.cfpgnjehw330.ap-south-1.rds.amazonaws.com',
    DB_USER : 'admin',
    DB_PWD : 'Ankit2002!',
    DB_DATABASE : 'webappdb'
});
